#ifndef _transitive_h_INCLUDED
#define _transitive_h_INCLUDED

struct kissat;

void kissat_transitive_reduction (struct kissat *);

#endif
