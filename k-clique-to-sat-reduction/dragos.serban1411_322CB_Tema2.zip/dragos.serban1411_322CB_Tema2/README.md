- deschidem fisierele primite ca argument
- citim nr n si k, apoi trecem pe fiecare linie din fisierul de input pt
fiecare nod in parte; cream matricea grafului
- inchidem fisierul de input
- calculam nr de clauze:
1. pt primul caz descris in tema vom avea k clauze
2. pt al doilea caz descris, calculam nr de perechi distincte, inmultim cu nr
de noduri si adaugam la nr de clauze
3. pt al treilea caz descris, nr locurile dintre 2 noduri unde nu exista niciun
muchii si il inmultim cu nr de perechi distincte
- alocam dinamic folosindu-ne de functia int **matrix(int row, int col)
o matrice ce contine clauzele pt SAT
- adaugam clauze de tipul 1 (k linii de cate n elemente
- adaugam clauze de tipul 2 (pt fiecare nod se vor adauga clauze pt fiecare
i si j, unde i < j si ambele sunt mai mici decat k; se vor adauga la matricea
pt SAT - crt reprezinta nr clauzei)
- adaugam clauze de tipul 3 (pt fiecare i si j cu i < n si j < n, vom lua toate
locurile dintre 2 noduri unde nu exista muchie din matricea grafului; pt
fiecare ii si jj, unde ii < jj si ii < k, jj < k; vom crea clauze ca cele date
in enuntul temei
- se va afisa rezultatul (matricea pt SAT, cu cate un zero la final de linie)
- se dezaloca memoria pt matricea unde au fost stocate clauzele
