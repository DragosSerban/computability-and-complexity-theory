#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NODES 100
#define MAX_STR 1024

int **matrix(int row, int col)
{
    int **a = malloc(row * sizeof(int *));
    if(!a) return NULL;
    for(int i = 0; i < row; i++)
    {
        a[i] = malloc(col * sizeof(int));
        if(!a[i])
        {
            for(int j = 0; j < i; j++)
                free(a[j]);
            return NULL;
        }
    }
    return a;
}

void free_matrix(int **A, int row)
{
    for(int i = 0; i < row; i++)
        free(A[i]);
    free(A);
}

int main(int argc, char *argv[])
{
    /* deschidere fisier + citire graf */
    FILE *f = fopen(argv[1], "r");
    if(!f)
        return 0;
    FILE *g = fopen(argv[2], "w");
    if(!g)
    	return 0;

    int n, k;
    int M[MAX_NODES][MAX_NODES] = {0};
    char str[MAX_STR];
    fscanf(f, "%d", &n);
    fscanf(f, "%d", &k);
    char new_line;
    fscanf(f, "%c", &new_line);
    int crt = 0;
    while(!feof(f) && fgets(str, MAX_STR, f)) {
        char *p = strtok(str, " ");
        while(p) {
            M[crt][atoi(p) - 1] = 1;
            M[atoi(p) - 1][crt] = 1;
            p = strtok(NULL, " \n");
        }
        crt++;
    }
    fclose(f);

    // calculam nr clauzelor
    int no_of_clauses = k;
    int no_of_distinct_pairs = (k - 1) * k / 2;
    no_of_clauses += (n * no_of_distinct_pairs);
    int no_of_not_edges = 0;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            if(!M[i][j])
                no_of_not_edges += 1;
    no_of_clauses += (no_of_distinct_pairs * no_of_not_edges);
    fprintf(g, "p cnf %d %d\n", k * n, no_of_clauses);

    // alocam matricea
    int **SAT = matrix(no_of_clauses, k * n);
    for(int i = 0; i < no_of_clauses; i++)
        for(int j = 0; j < k * n; j++)
            SAT[i][j] = 0;

    // adaugam clauze de tipul 1
    int temp = 0;
    for(int i = 0; i < k; i++) {
        for(int j = temp; j < temp + n; j++)
            SAT[i][j] = j + 1;
        temp += n;
    }

    // adaugam clauze de tipul 2
    crt = k;
    for(int l = 0; l < n; l++)
        for(int i = 0; i < k; i++)
            for(int j = i + 1; j < k; j++) {
                SAT[crt][i * n + l] = - (i * n + l + 1);
                SAT[crt][j * n + l] = - (j * n + l + 1);
                crt++;
            }

    // adaugam clauze de tipul 3 (pt fiecare nemuchie din graf)
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            if(!M[i][j])
                for(int ii = 0; ii < k; ii++)
                    for(int jj = ii+1; jj < k; jj++) {
       	                SAT[crt][ii * n + i] = - (ii * n + i + 1);
        	        SAT[crt][jj * n + j] = - (jj * n + j + 1);
       		        crt++;
                    }

    // afisare rezultat
    for(int i = 0; i < no_of_clauses; i++) {
        for(int j = 0; j < k * n; j++)
            if(SAT[i][j])
                fprintf(g, "%d ", SAT[i][j]);
        fprintf(g, "0\n");
    }
    fclose(g);
    
    free_matrix(SAT, no_of_clauses);

    return 0;
}
